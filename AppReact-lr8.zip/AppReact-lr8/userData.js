export default [
  {
    id: "1",
    title: "Strength",
    description: "Bonk!",
    image: require("./assets/imagestr.jpg"),
  },
  {
    id: "2",
    title: "Agility",
    description: "Dodge!",
    image: require("./assets/imageagi.jpg"),
  },
  {
    id: "3",
    title: "Intelligence",
    description: "Magic!",
    image: require("./assets/imageint.jpg"),
  },
  {
    id: "4",
    title: "title",
    description: "AdaptiveIcon",
    image: require("./assets/adaptive-icon.png"),
  },
];
